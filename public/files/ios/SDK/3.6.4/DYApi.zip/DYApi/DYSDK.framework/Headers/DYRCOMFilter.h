//
//  DYRCOMFilter.h
//  DYSDK
//
//  Created by Idan Oshri on 04/06/2019.
//  Copyright © 2019 dynamicyield. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef enum {
    DY_FILTER_INCLUDE,
    DY_FILTER_EXCLUDE
} DYFilterType;

typedef enum {
    DY_FILTER_SKU,
    DY_FILTER_GROUP_ID
} DYFilterField;


@interface DYRCOMFilter : NSObject

@property DYFilterType filterType;
@property DYFilterField filterField;
@property (strong,atomic) NSArray* filterValue;

/*!
 *  Filter the results of the recommendation request call, Whitelisting and Blacklisting products
 *  by their SKU or groupID
 *
 *  @param filterType - DY_FILTER_INCLUDE/DY_FILTER_EXCLUDE
 *  @param filterField - DY_FILTER_SKU/DY_FILTER_GROUP_ID
 *  @param value - The SKU or groupID
 *
 *  @return DYRCOMFilter instance
 */

+(DYRCOMFilter*)filterWithType:(DYFilterType)filterType Field:(DYFilterField)filterField Value:(NSArray*)value;
-(NSDictionary*)getJSON;
@end

NS_ASSUME_NONNULL_END
